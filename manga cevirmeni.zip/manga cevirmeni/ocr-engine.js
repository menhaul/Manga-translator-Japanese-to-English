async function processMangaSelection(rect) {
    chrome.runtime.sendMessage({action: "capture_screen"}, async (response) => {
        if (!response || response.error) return;

        const image = new Image();
        image.src = response.imgData;
        image.onload = async () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const dpr = window.devicePixelRatio || 1;
            
            canvas.width = rect.width * dpr;
            canvas.height = rect.height * dpr;
            
            ctx.filter = 'grayscale(1) contrast(1.5)';
            ctx.drawImage(image, rect.left * dpr, rect.top * dpr, rect.width * dpr, rect.height * dpr, 0, 0, canvas.width, canvas.height);

            try {
                const worker = await Tesseract.createWorker('jpn_vert');
                await worker.setParameters({
                    tessedit_pageseg_mode: '5',
                });

                const { data: { text } } = await worker.recognize(canvas.toDataURL());
                
                const cleanText = text.replace(/[^\u3000-\u303f\u3040-\u309f\u30a0-\u30ff\uff00-\uff9f\u4e00-\u9faf\u3400-\u4dbf]/g, '').trim();

                if (cleanText.length > 0) {
                    const translated = await translateToEnglish(cleanText);
                    showTranslation(translated, rect);
                }
                await worker.terminate();
            } catch (err) { console.error("OCR Error:", err); }
        };
    });
}

async function translateToEnglish(jpText) {
    const text = jpText.replace(/\s+/g, '');
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=ja&tl=en&dt=t&q=${encodeURIComponent(text)}`;
    try {
        const res = await fetch(url);
        const data = await res.json();
        return data[0].map(x => x[0]).join(' ');
    } catch (e) { return "Translation error."; }
}