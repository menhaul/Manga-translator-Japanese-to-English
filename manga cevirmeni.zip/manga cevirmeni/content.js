let isDrawing = false;
let startX, startY, selectionBox;
let keysPressed = {};

const style = document.createElement('style');
style.innerHTML = `
    .manga-mode-active * {
        user-select: none !important;
        -webkit-user-drag: none !important;
        cursor: crosshair !important;
    }
`;
document.head.appendChild(style);

document.addEventListener('keydown', (e) => {
    keysPressed[e.key] = true;
    if (keysPressed['Shift'] && (keysPressed['s'] || keysPressed['S'])) {
        document.body.classList.add('manga-mode-active');
    }
});

document.addEventListener('keyup', (e) => {
    delete keysPressed[e.key];
    if (!keysPressed['Shift'] || !(keysPressed['s'] || keysPressed['S'])) {
        document.body.classList.remove('manga-mode-active');
    }
});

document.addEventListener('mousedown', (e) => {
    if (!(keysPressed['Shift'] && (keysPressed['s'] || keysPressed['S'])) || e.button !== 0) return;
    isDrawing = true;
    startX = e.pageX;
    startY = e.pageY;
    selectionBox = document.createElement('div');
    Object.assign(selectionBox.style, {
        border: '2px solid #00ff00',
        position: 'absolute',
        backgroundColor: 'rgba(0, 255, 0, 0.15)',
        zIndex: '2147483647',
        pointerEvents: 'none'
    });
    document.body.appendChild(selectionBox);
});

document.addEventListener('mousemove', (e) => {
    if (!isDrawing) return;
    selectionBox.style.width = Math.abs(e.pageX - startX) + 'px';
    selectionBox.style.height = Math.abs(e.pageY - startY) + 'px';
    selectionBox.style.left = Math.min(e.pageX, startX) + 'px';
    selectionBox.style.top = Math.min(e.pageY, startY) + 'px';
});

document.addEventListener('mouseup', () => {
    if (!isDrawing) return;
    isDrawing = false;
    const rect = selectionBox.getBoundingClientRect();
    if (rect.width > 5) processMangaSelection(rect);
    selectionBox.remove();
});

function showTranslation(text, rect) {
    const old = document.getElementById('manga-popup');
    if (old) old.remove();
    const box = document.createElement('div');
    box.id = 'manga-popup';
    box.innerText = text;
    Object.assign(box.style, {
        position: 'absolute',
        left: (rect.left + window.scrollX) + 'px',
        top: (rect.bottom + window.scrollY + 10) + 'px',
        backgroundColor: '#000',
        color: '#fff',
        padding: '12px',
        borderRadius: '8px',
        fontSize: '15px',
        zIndex: '2147483647',
        maxWidth: '300px',
        border: '1px solid #00ff00',
        boxShadow: '0 4px 15px rgba(0,0,0,0.5)',
        cursor: 'pointer'
    });
    document.body.appendChild(box);
    box.onclick = () => box.remove();
    setTimeout(() => { if(box) box.remove(); }, 15000);
}